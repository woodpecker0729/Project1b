package project2.ver02;

public interface MenuChoice {
	final int MAKE=1;
	final int DEPOSIT=2;
	final int WITHDRAW=3;
	final int INQUIRE=4;
	final int EXIT=5;
}
