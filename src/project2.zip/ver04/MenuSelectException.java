package project2.ver04;

public class MenuSelectException extends Exception{
	public MenuSelectException() {
		// TODO Auto-generated constructor stub
		super("1~5사이의 정수를 입력하세요");
	}
	
}
