package project2.ver03;


public abstract class Account implements CustomSpecialRate{
	public String account;
	public String name;
	public int money;
	
	
	public void depositMoney(int money) {}
	public void withdrawMoney(int money) {}
	public void showAccInfo() {}
	
}
