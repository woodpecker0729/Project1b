package project2.ver03;

public interface CustomSpecialRate {
	final int A = 7;
	final int B = 4;
	final int C = 2;
	
}
